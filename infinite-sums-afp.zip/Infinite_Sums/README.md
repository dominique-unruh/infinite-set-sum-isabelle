Formalization of infinite sums in Isabelle/HOL

Author: Dominique Unruh
Licence: BSD 3-clause
